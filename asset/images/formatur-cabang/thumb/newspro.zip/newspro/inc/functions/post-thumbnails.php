<?php
	set_post_thumbnail_size( 50, 50, true); // Normal Post Thumbnails
	add_image_size( 'gab_featured', 700, 9999 ); // Featured Big Image
?>
